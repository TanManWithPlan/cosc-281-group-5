"""Team navigation package."""
